<!DOCTYPE html>
<html>
	<head>
		<title>Inicio de sesión</title>
		<meta charset="utf-8">
	</head>
	<body>
		<form action="loginBBDD.php" method="post">
			<fieldset>
			<legend>Inicio de sesión</legend>
			Nick:
			<input type="text" name="nick" />
			</br>
			Contraseña:
			<input type="password" name="pass" />
			</br>
			<input type="submit" name="login" value="Entrar">
			</fieldset>
		</form>
	</body>
</html>