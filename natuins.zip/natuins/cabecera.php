<!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
	<title>Cabecera</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/cabecera.css">
</head>
<body>
	<div id ="cabecera">
		<div id="logo">
			<img src="img/logotipo1.png">
		</div>
		<div id="action">
			<a href="">Mi perfil</a>
			<a href="">Salir</a>
		</div>
	</div>
</body>
</html>