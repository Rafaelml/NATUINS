<?php
    require_once ("models/UserR.php");
	$nick = htmlspecialchars(trim(strip_tags($_REQUEST["nick"])));
	$password = htmlspecialchars(trim(strip_tags($_REQUEST["pass"])));
	$usuario = new UserR();
    if($usuario->init_Session($nick,$password)){
        header('Location: index.php');
    }
    else{
        echo 'Usuario incorrecto inténtelo de nuevo.';
        exit();
        header('Location: login.php');
    }
?>