<!DOCTYPE html>
<html>
<head>
    <title></title>
    <meta charset="utf-8">
</head>
<body>
<p>Está parte todavía no ha sido implementada.</p>
<a href="index.php">Volver atrás</a>
</body>
</html>