<!DOCTYPE html>
<html>
<head>
    <title>Inicio</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="views/css/estilo.css">
</head>
<body>
<div id="contenedor">
    <div id="cabecera">
        <div id="logo">
            <h1>NATUINS</h1>
        </div>
        <div id="navegador">
            <ul>
                <li><a href="registro.php">Registro</a></li>
                <li><a href="login.php">Login</a></li>
            </ul>
        </div>
    </div>

    <div id="sidebar-left">
        <a href="noimplem.php">Tendencias</a>
        <p>#MadridVSJuve</p>
        <p>#EsPenalti</p>
        <p>#CristianoTheBest</p>
    </div>

    <div id="contenido">
        <div id="tuins">
            <?php
            require_once ("controllers/Controller.php");
            $controller =new Controller();
            echo $controller->viewTuins();

            ?>
        </div>
    </div>

    <div id="sidebar-right">
        <a href="noimplem.php">Personas destacadas</a>
    </div>
</div>
</body>
</html>