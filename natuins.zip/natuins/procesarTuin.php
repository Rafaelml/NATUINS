<?php
	session_start();
	$tuin = htmlspecialchars(trim(strip_tags($_REQUEST["tuin"])));
	$idUser = $_SESSION['idUser'];

	if(empty($tuin)){
		exit();
	}
    require_once ("models/UserR.php");
    $usuario = new UserR();
	$usuario->createTuin($tuin,$idUser);
	header("Location: index.php");

?>