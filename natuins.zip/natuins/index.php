<?php
            session_start();
            if(isset($_SESSION['usuario']) == null) {
                header('location: inicio.php');
            }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Index</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="views/css/estilo.css">
</head>
<body>
	<div id="contenedor">

		<div id="cabecera">
			<div id="logo">
				<h1>NATUINS</h1>
			</div>
			<div id="navegador">
				<ul>
					<li><a href="noimplem.php">Notificaciones</a></li>
					<li><a href="noimplem.php">Destacados</a></li>
					<li><a href="noimplem.php">Buscador</a></li>
					<li><a href="noimplem.php">Mensajes</a></li>
					<li><a id="salir" href="logout.php" name="salir">Salir</a></li>
				</ul>
			</div>
		</div>

		<div id="sidebar-left">
			<a href="noimplem.php">Tendencias</a>
			<p>#MadridVSJuve</p>
			<p>#EsPenalti</p>
			<p>#CristianoTheBest</p>
		</div>

		<div id="contenido">
		<?php
        if(isset($_SESSION['usuario']) != null) {
                echo '<h1>Bienvenido a Natuins ' . $_SESSION['usuario'] . '</h1>';
            }
		?>

			<p>Escribe un tuin:</p>

			<div id="mensaje">
				<form action="procesarTuin.php" method="post">
					<textarea rows="5" cols="68" name="tuin"></textarea>
					<p><input type="submit" name="login" value="Enviar"></p>
				</form>
			</div>

			<div id="tuins">
			<?php
            require_once ("models/UserR.php");
            $usuario = new UserR();
            $tuins =$usuario->viewTuins();
            $count =count($tuins);
            for ($i = 0; $i < $count; $i++) {
                echo '<div id="tuin">';
                echo '<p>' . $tuins[$i]["tuin"] . '</p>';
                echo '<p>' . $tuins[$i]["0"] . '</p>';
                echo '</div>';
				}
			?>
			</div>
		</div>

		<div id="sidebar-right">
			<a href="noimplem.php">Personas a las que seguir</a>
		</div>

	</div>
</body>
</html>