<?php
/**
 * Created by PhpStorm.
 * User: rafael
 * Date: 20/4/18
 * Time: 18:39
 */
require_once ("models/UserNoR.php");
class Controller{
    public function construct()
    {

    }
    public function viewTuins(){
        $mostrar ="";
            $usuario = new UserNoR();
            $tuins =$usuario->viewTuins();
            $count =count($tuins);
            for ($i = 0; $i < $count; $i++) {
                $mostrar .='<div id="tuin">';
                $mostrar .= '<p>' . $tuins[$i]["tuin"] . '</p>';
                $mostrar .= '<p>' . $tuins[$i]["0"] . '</p>';
                $mostrar .='</div>';
            }
            return $mostrar;
}

}
?>